## AC7 PVE Installation Guide (v1.1.0 — Distribution Release)

This is a campaign co-op mode for the PC (Steam) version of 《ACE COMBAT 7: SKIES UNKNOWN》.
It supports 2–8 players, and bugs may be found in some missions.

**\*Please read the operating instructions and cautions carefully!!\***

==============================

## How It Works

* After launching the launcher, press the Apply (Install/Patch) button to obtain the patch.
* In the \[설정] tab, you can configure various options for playing this mod. To apply the options, you must press the \[저장] button at the bottom. After applying the options, you do not need to restart the game or hosting.
(Change setting values with the mouse wheel, by clicking the right arrow, or by double-clicking the setting field.)
* In the \[플레이] tab, press \[세이브 백업 후 실행] to start the game.
※ At this time, confirm that every item in the \[점검항목] tab is displayed in green.
* The Host can create a session by pressing the \[호스트] button in the \[플레이] tab, then send invitations to Steam friends by pressing the \[스팀 오버레이] button.
※ Players who are not Steam friends can join when the Host sends them the session join code through another messenger.
* Guests accept the Steam invitation sent by the Host, or join by pasting the session code into the 참가코드 tab.
* Guests can become members of the Host's squadron, or become interference players and interfere with the Host.
(The Host must enable the option in settings to allow joining as an interference player.)
* Immediately before playing, check that the usernames and number of users you invited are displayed in the bottom \[명단/친구] tab.
* When the Host starts the desired mission, the Guests will load into the mission automatically.
※ Refer to the cautions below.

==============================

## Cautions

**!!Very Important!!
When playing PVE mode for the first time, the Host must wait until the Guests have finished preparing for sortie.**

* &#x20;If the Host starts a mission during the first play session before the Guests have finished preparing for sortie, the Guests may be unable to enter the mission, or settings may change abnormally, causing key bindings, sound settings, aircraft settings, and other settings to become incorrect.
Once the Guests' aircraft and weapon settings are saved after the first play session, their most recent settings are loaded automatically from then on. To change a Guest's aircraft settings, the Host must wait again.
(When configuring aircraft settings, there is no need to match the Host's mission/difficulty, etc.)
* Certain setting values may cause a session to crash or prevent smooth play. Configure them according to your PC specifications.
e.g.) Setting the enemy spawn count too high or inviting more than 4 users puts a heavy load on the Host PC.
* If an invited user has set their Steam game activity to private or has fixed their status to offline, their play status cannot be detected. That user should join through the session invitation code.
* Public lobbies are still being tested. Using Steam invitations/session codes is recommended.

==============================

## Planned Updates

* Update ACE+—the highest difficulty available through the current difficulty customization—so that enemy aircraft engage in dogfight-style battles
* Update Interference Mode from beta to an official release (add content and improve stability and efficiency)

==============================

## Other Cautions



* This mod has safeguards designed in many areas, so it is expected not to cause major problems with save/game files. However, backing up saves is recommended just in case.



* The AC7 save location is as follows.
C:\\UsersUsername\\AppData\\Local\\BANDAI NAMCO Entertainment\\ACE COMBAT 7\\SaveGames



* Crashes may occasionally occur for reasons such as not following the stated procedure and cautions, but game files will not be affected.



* If your Steam nickname contains special symbols/characters that do not support ASCII characters, that nickname will not be displayed in-game.



* For bug reports, please contact the 59th Squadron Discord server or the email address below.
Discord server link: https://discord.gg/EWTwSRpgXE
Personal email: jeonspace08@gmail.com

